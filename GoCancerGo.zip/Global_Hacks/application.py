import os
import random
from datetime import datetime
from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session,url_for, send_file
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import apology, login_required
from datetime import datetime
from base64 import b64encode
import base64
from io import BytesIO #Converts data from Database into bytes



# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response



# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")



Session(app)
# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///user.db")


@app.route('/')
def index():
  return render_template("index.html")

@app.route('/question',methods=["GET","POST"])
def question():
   if request.method == 'GET':
      return render_template('question.html')
   else:
      q = request.form.get("question")
      db.execute("INSERT INTO faq(Question) VALUES(:q)", q = q)
      return redirect("/help")

@app.route("/medical_services", methods=["GET"])
def medical_services():
   if request.method == 'GET':
      location = db.execute("SELECT state FROM user WHERE user_id = :i",i = session["user_id"])
      rows = db.execute("SELECT * FROM services WHERE city=:f", f = location[0]['state'])
      return render_template("medical_services.html",rows=rows)

@app.route("/connect", methods = ["GET","POST"])
def connect():
   if request.method == "GET":
      rows = db.execute("SELECT * FROM user")
      return render_template("connect.html",rows=rows)
   else:
      id = db.execute("SELECT user_id FROM user WHERE name =:n",n=request.form.get("name"))
      name = db.execute("Select name FROM user WHERE user_id=:i",i=session['user_id'])
      ida = str(id[0]['user_id'])+str(session['user_id'])
      print(ida)
      rows = db.execute("SELECT * FROM chat WHERE id = :id1 AND name =:n" ,id1 = ida,n=name[0]["Name"])
      rowsn = db.execute("SELECT * FROM chat WHERE id = :id1 AND name =:n" ,id1 = ida,n=request.form.get("name"))
      m = name[0]['Name']
      return render_template("chat.html",rows=rows,rowsn=rowsn,l=len(rowsn),m = m)

@app.route("/chat", methods = ["GET","POST"])
def chat():
   if request.method == 'POST':
      now = datetime.now()
      name = db.execute("Select Name FROM user WHERE user_id=:i",i=session['user_id'])
      id = db.execute("SELECT user_id FROM user WHERE name =:n",n=request.form.get("name"))
      m = request.form.get("name")
      print(request.form.get("name"))
      ida = str(id[0]['user_id'])+str(session["user_id"])
      db.execute("INSERT INTO chat (chatus,name,time,id) VALUES (:c,:n,:t,:i) ",c = request.form.get("chat"),n = name[0]['Name'],t=now,i=ida)
      name = name[0]['Name']
      id = db.execute("SELECT user_id FROM user WHERE name =:n",n=name)
      name = db.execute("Select Name FROM user WHERE user_id=:i",i=session['user_id'])
      ida = str(id[0]['user_id'])+str(session["user_id"])
      rows = db.execute("SELECT * FROM chat WHERE id = :id1 AND name =:n" ,id1 = ida,n=name[0]['Name'])
      rowsn = db.execute("SELECT * FROM chat WHERE id = :id1 AND name =:n" ,id1 = ida,n=request.form.get("name"))
      return render_template("chat.html",rows=rows,rowsn=rowsn,m=m)


@app.route("/help",methods=["GET","POST"])
def help():
   if request.method == 'GET':
      rows = db.execute("SELECT * FROM faq WHERE Answer IS NOT NULL")
      rowsn = db.execute("SELECT * FROM faq WHERE Answer IS NULL")
      return render_template("faq.html",rows=rows,rowsn=rowsn)
   else:
      ans = request.form.get("answer")
      q = request.form.get("question")
      print(q)
      print(ans)
      db.execute("DELETE FROM faq WHERE Question = :q",q=q)
      db.execute("INSERT INTO faq (Question, Answer) VALUES(:q,:ans)",q=q,ans=ans)
      return redirect('/help')


@app.route("/register", methods=["GET", "POST"])
def register():
   if request.method == "GET":
      return render_template("register.html")
   else: #checking if all fields entered
        if not request.form.get("username"):
            return apology("must provide username", 403)
        else:
          username = request.form.get("username")
        if not request.form.get("name"):
            return apology("must provide name", 403)
        else:
           name = request.form.get('name')
        if not request.form.get("email"):
            return apology("must provide email", 403)
        else:
            email = request.form.get('email')
        if not request.form.get("States"):
            return apology("must provide location", 403)
        else:
            state = request.form.get("States")
        if not request.form.get("Cancer"):
            return apology("must provide condition", 403)
        else:
            cancer = request.form.get("Cancer")
        if not request.form.get("age"):
            return apology("must provide age", 403)
        else:
            age = request.form.get("age")
        if not request.form.get("password"):
            return apology("must provide password", 403)
        if not request.form.get("confirmation"):
            return apology("must enter password again", 403)
        if request.form.get("password") != request.form.get("confirmation"):
            return apology("The passwords must match", 403)
        if not request.form.get("Role"):
            return apology("must provide role", 403)
        else:
           role = request.form.get("Role")
        if role == "patient":
            rows = db.execute("SELECT username FROM user")
            for row in rows:
                if request.form.get("username") == row["username"]:
                    return apology("This username is already taken", 403)
        if role == "family":
            rows = db.execute("SELECT username FROM family")
            for row in rows:
                if request.form.get("username") == row["username"]:
                    return apology("This username is already taken", 403)


        password = generate_password_hash(request.form.get("password"))
        if role == "patient":
            db.execute("INSERT INTO user (password, age, type_of_cancer, state, email, Name, username) VALUES (:pa,:ag,:ty,:st,:em,:na, :us)", pa=password,ag=age, ty = cancer, st = state, em = email, na = name, us = username)
            rows = db.execute("SELECT * FROM user WHERE username = :name",name=username)
            session["user_id"] = rows[0]["user_id"]
            session['username'] = username
            return redirect("/login")
        else:
            db.execute("INSERT INTO family (password, name, email, age, state, cancer, username) VALUES (:us, :pa,:ag,:ty, :st, :em, :na)", us=password, pa=name,ag=email,ty=age, st = state, em = cancer, na = username)
            rows = db.execute("SELECT * FROM family WHERE username = :name AND name = :n",name=username, n = name)
            session["user_id"] = rows[0]["user_id"]
            session['username'] = username
            return redirect("/login")

@app.route("/login", methods=["GET", "POST"])
def login():
  session.clear()
  if request.method == "POST":
        # Ensure username was submitted
      if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
      elif not request.form.get("password"):
            return apology("must provide password", 403)

      elif not request.form.get("name"):
         return apology("must provide name", 403)

        # Query database for usernam
      rows = db.execute("SELECT * FROM user WHERE username = :name AND Name = :n",name=request.form.get("username"), n = request.form.get("name"))
      if len(rows) == 0:
        role = "family"
        rows = db.execute("SELECT * FROM family WHERE username = :name AND name = :p",name=request.form.get("username"), p = request.form.get("name"))
        if len(rows) != 1 or not check_password_hash(rows[0]["password"], request.form.get("password")):
            return apology("invalid username and/or password", 403)
        session["user_id"] = rows[0]["user_id"]
      else:
        rows = db.execute("SELECT * FROM user WHERE username = :name",name=request.form.get("username"))

        if len(rows) != 1 or not check_password_hash(rows[0]["password"], request.form.get("password")):
          return apology("invalid username and/or password", 403)
        role = "patient"
        session["user_id"] = rows[0]["user_id"]
      session["role"] = role
      return render_template("index.html",role=role,login=login)

  else:
    return render_template("login.html")

@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")